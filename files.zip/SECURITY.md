# Security Policy

- Simulated data only. Do not upload real organizational logs or secrets.
- For vulnerabilities in this repo, open a private GitHub Security Advisory or contact the maintainer directly.